<?php
echo "<h1>Welcome, Guest</h1>";
echo "<h1>Payment Canceled</h1>";
?>